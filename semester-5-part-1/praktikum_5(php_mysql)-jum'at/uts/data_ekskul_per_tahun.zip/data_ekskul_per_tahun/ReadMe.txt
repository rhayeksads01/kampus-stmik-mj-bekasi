intruksi penggunaan :
1. jalankan server mysql pada xampp
2. pilih menu sql yang ada di menu bar pada phpmyadmin
3. lalu copy dan pastekan script code yang ada didalam file import.sql ke kolom(text area) sql query
4. lalu kirim
5. setelah itu pilih nama database data_ekskul_per_tahun yang ada disidebar sebelah kiri
6. selanjutnya pilih menu sql yang ada di menu bar
7. kemudian copy dan pastekan script code yang ada didalam file commands.sql sesuai kebutuhan ke kolom(test area) sql query
