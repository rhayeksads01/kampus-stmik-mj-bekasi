<html>

<head>
    <title>latihan mengirim dengan get</title>
</head>

<body>
    Dibawah ini adalah form yang akan dikirimkan ke halaman web bernama
    lat9.php
    <form name="dataku" action="lat9.php" method="get">
        Masukkan Nama Anda:

        <input type="text" name="namaku">
        <br>
        ini tombol input dengan type="submit" :
        <input type="submit" value="Kirimkan" />
</body>

</html>