<html>

<head>
    <title>tugas 3</title>
</head>

<body>
    <?php
    $a = 5;
    $b = $a + 3;
    echo $a;
    echo "<br>";
    echo $b;
    $c = "buku ini bagus " . $a;
    echo "<br>" . $c;
    ?>
</body>

</html>