<html>

<head>
    <title>latihan menggunakan array lanjutan</title>
</head>

<body>
    <?php
    $fruit = array("Aplle", "Banana", "Orange", "Mango");
    list($red_fruit, $orange_fruit) = $fruit;
    echo $red_fruit . " <br> ";
    echo $orange_fruit;
    echo " <br> ";
    ?>
</body>

</html>