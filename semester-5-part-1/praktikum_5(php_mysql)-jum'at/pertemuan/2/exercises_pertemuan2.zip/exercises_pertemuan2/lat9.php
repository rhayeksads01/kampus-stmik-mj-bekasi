<html>

<head>
    <title>latihan penerima</title>
</head>

<body>
    <?php
    echo "SELAMAT DATANG ";
    echo $_GET["namaku"];
    ?>
</body>

</html>