<html>

<head>
    <title>tugas 2</title>
</head>

<body>
    <?php
    define("JUDUL", "Pemrograman PHP");
    echo "teks ini adalah isi konstanta JUDUL= ";
    echo JUDUL;
    echo "<br>";
    define("HARGA", 1000);
    echo "teks ini adalah isi konstanta HARGA + 100= ";
    echo HARGA + 100;
    ?>
</body>

</html>