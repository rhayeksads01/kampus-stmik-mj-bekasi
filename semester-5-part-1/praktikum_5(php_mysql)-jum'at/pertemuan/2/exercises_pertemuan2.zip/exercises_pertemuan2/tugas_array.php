<html>

<head>
    <title>latihan menggunakan array</title>
</head>

<body>
    <?php
    $array = array("A", "B", "C", "D");
    $array2[0] = 0;
    $array2[1] = 15;
    $array2[2] = 16;
    $array2[3] = 17;
    $array2[4] = 18;
    $matriks[1][1] = 15;
    $matriks[1][2] = 17;
    $matriks[2][1] = 18;
    $matriks[2][2] = 19;
    $nilaimutu = $array[3];

    list($adit, $andri, $gofo) = $array2;

    echo "isi elemen array pada indeks 3 = ";
    echo $array[3];
    echo "<br>";
    echo "isi elemen array2 pada indeks 2 = ";
    echo $array2[2];
    echo "<br>";
    ?>
</body>

</html>