<html>

<head>
    <title>tugas 4</title>
</head>

<body>
    <?php
    $a = 5;
    $b = $a + 3;
    define("NILAI1", 100);
    define("NILAI2", 200);

    echo $a;
    echo " <br> " . $b;
    echo " <br> " . $b . NILAI1;
    echo " <br> " . (NILAI1 . NILAI2);
    ?>
</body>

</html>