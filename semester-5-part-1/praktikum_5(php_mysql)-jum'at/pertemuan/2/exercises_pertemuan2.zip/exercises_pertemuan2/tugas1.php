<html>

<head>
    <title>tugas 1</title>
</head>

<body>
    <?php
    $judul = "Pemrograman PHP";
    echo "teks ini adalah isi variabel judul= ";
    echo $judul;
    echo "<br>"
    ?>
    <br>
    <?php
    $harga = "Seribu";
    echo "teks ini adalah isi variabel harga= ";
    echo $harga;
    ?>
</body>

</html>