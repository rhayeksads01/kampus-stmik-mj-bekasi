<html>

<head>
    <title>latihan menggunakan perulangan</title>
</head>

<body>
    <?php
    $judul = "pemrograman PHP";
    echo "judul di cetak 5 kali";
    echo "<br>";
    $a = 1;
    while ($a <= 5) {
        echo "4judul";
        echo "<br>";
        $a = $a + 1;
    }
    ?>
</body>

</html>